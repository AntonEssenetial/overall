'use strict';

svg4everybody();

$(function() {
    FastClick.attach(document.body);
});
  
// Modules
// main-menu
(function() {

    var link = $('.main-menu__link');

    if(!link.hasClass('is-active')) {
        link.mouseover(function(event) {
            $(this).addClass('is-active')
        })
        link.mouseleave(function(event) {
            var self = $(this);
            setTimeout(function(){
                self.removeClass('is-active')
            },300);
        });
    }

})();

// module__scroll-down
(function() {

    var scroll = $('.jsScroll'),
        jsHeight = $(window).height();

    scroll.click(function(event) {
        $('body').animate({
            scrollTop: jsHeight
        },1000);
    });

})();

// module__top-slider
(function() {

    $(document).ready(function($) {
       // slick slider 
        var slider1 = $('.jsSlick');
        slider1.slick({
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: true,
            customPaging: function(slider, i) {
                var title = $(slider.$slides[i]).data('slide')
                return '<div class="slick-wrapper"><span class="slick-button"></span></div><span class="slick-title">' + title + '</span>';
            },
            arrows: false,
            fade: true
        }); 

    });

})();

// module__top
(function() {

    var jsHeight = $('.jsHeight');
    function topHeight(){
        if ($(window).width() <= 767) {
            jsHeight.css('height', 'auto');
        } else {
            jsHeight.css('height', $(window).height());
        }
    }

    $(window).on('load', function() {
        topHeight();
    });
    $(window).on('resize', function() {
        topHeight();
    });

})();

// Sandwitch
(function() {

    $('.jsMobileDropdown').click(function(event) {
        
        var sandWitch = $('.module__main-menu'),
            menu = $('.toggle-menu');

        sandWitch.toggleClass('active');        
        menu.toggleClass('active');
        $('html').toggleClass('page_mobile-menu');
        
        if(!scrollers[0].element.hasClass('mCS_disabled')){
            scrollers[0].element.mCustomScrollbar('disable', true)
        } else {
            setTimeout(function(){
                scrollers[0].element.mCustomScrollbar('update')
            }, 400)
        }


    });

    $(window).on("load resize",function(){
        $('body').css('height', $(window).height());
        scrollers[0].element.mCustomScrollbar(scrollers[0].params); 
    });

    var scrollers = [
        {
            element: $('body'),
            params:{
                scrollInertia:100,
                autoHideScrollbar: true
            },
            options:{
                type:'width',
                value: 1024
            }
        }
    ]

})();

